

echo "**** Start compling scripts ****"
exename="SMB_simu_${run}"
rm *.o *.mod SMB_simulation.x

gfortran -O2 -mcmodel=large -c variables.f90
echo "*** Variables compiled"
#gfortran -O3 -c variables_snow.f90
gfortran -O2 -mcmodel=large -I/home/tobias/PhD/Programming/NEW/system/include -c io.f90
echo "*** Io compiled"
gfortran -O2 -mcmodel=large -c smb_emb.f90
echo "*** SMB EMB compiled"
#gfortran -O3 -c smb_pdd.f90

gfortran -O2 -mcmodel=large -L/home/tobias/PhD/Programming/NEW/system/lib -o ${exename}.x variables.o io.o smb_emb.o IceBern2D.f90  -lnetcdff 

echo "*** Ice Bern compiled"


echo $exename".x"
echo "**** Run model ****"
./${exename}.x > output_${run_str}.txt

run_num=$(printf "%05d" $run)
echo "**** change to output directory ****"
