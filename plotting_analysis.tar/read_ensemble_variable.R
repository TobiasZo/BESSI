read_ensemble_variable <- function(variable,ensemblesize,period){
  #amount of runs/files
  library(chron)
  library(RColorBrewer)
  library(lattice)
  library(ncdf4)
  
  nstart=1
  n=ensemblesize
  #read MB data
  setwd("/home/tobias/PhD/Programming/NEW/modeloutput/output_netcdfs")
  #setwd("/home/tobias/PhD/Programming/NEW/modeloutput/output")
  ncname <- paste(variable,"_",ensemblesize,"ensemble_",period,sep="")
  ncfname <- paste(ncname, ".nc", sep = "")
  # open a NetCDF file to get vars
  ncin <- nc_open(ncfname)
  # print(ncin)
  MB <- ncvar_get(ncin,variable)
  nc_close(ncin)
  rm(ncin)
  rm(ncfname,ncname)
  gc()
  Sys.sleep(10)
  gc()
  return(MB)
  
  
  
  
}