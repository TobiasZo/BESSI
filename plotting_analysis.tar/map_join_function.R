#joining different regions and map

map_join<-function(map1,map2){
  
  # map1=regions_grad
  # map2=elevation_mask
  map1=map1
  map2=map2*100
  
  map3=map1+map2

  values=na.exclude(unique(c(map3),na.rm=TRUE))
  values=sort(values)
  for (i in 1:length(values)){
    map3[map3==values[i]]=i-1
  }
  # filled.contour(map3,levels=c(1:20))
  
  return(map3)
}