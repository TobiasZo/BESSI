#MB_cumulative plots for individual regions 
#install.packages("ncdf4", lib="/work/zolles/libs/Rlibs")

library(chron)
library(RColorBrewer)
library(lattice)
library(ncdf4)


# Reading netcdfs --------------------------------------------------
#setwd("/home/tobias/PhD/Programming/NEW/modeloutput/ensemble_00001_a_new0775_a_wet0575_a_i035_D_sf15_D_lf085_eps075_latent0_a_mod3_lwc012018_06_09_1300_24/")
# setwd("/home/tobias/PhD/Programming/NEW/modeloutput/")
 setwd("/home/tobias/PhD/Programming/NEW/input/ERA_interim/grl10_interp/")
#get ice matrix from height etopo
ncname <- 'etopo_grl10_landmask'
ncfname <- paste(ncname, ".cdf", sep = "")
# open a NetCDF file to get vars
ncin <- nc_open(ncfname)
# print(ncin)
#y <- ncvar_get(ncin,"y")
#ny <- dim(y)
#head(y)
#x <- ncvar_get(ncin,"x")
#nx <- dim(x)
#head(x)
# get time
#time <- ncvar_get(ncin,"time")
bedrock  <- ncvar_get(ncin,"BED_INTERP")
bedrock_i=bedrock[,]
elevation <- ncvar_get(ncin,"SURFACE_INTERP")
elevation_i=elevation[,]
ice_i = elevation_i-bedrock_i
assignment_mask=ice_i
assignment_mask[elevation_i<0]=0
assignment_mask[ice_i<0]=1 ##check is new for calibration
assignment_mask[elevation_i<0]=0
assignment_mask[ice_i<100&ice_i>0]=2##check is new for calibration
assignment_mask[elevation_i<=0]=0
assignment_mask[ice_i>100]=3##check is new for calibration
assignment_mask_i=assignment_mask##check is new for calibration
#rm(assignment_mask_i)
rm(bedrock_i)
rm(elevation)
rm(bedrock)
rm(assignment_mask)
nc_close(ncin)
rm(ncin,ncname, ncfname)

#get ice matrix from height etopo
if (period=="ERAi"){
  ncname <- 'IceBern2D_0000001'
  ncfname <- paste(ncname, ".nc", sep = "")
  # open a NetCDF file to get vars
  ncin <- nc_open(ncfname)
  # print(ncin)
  y <- ncvar_get(ncin,"y")
  ny <- dim(y)
  head(y)
  x <- ncvar_get(ncin,"x")
  nx <- dim(x)
  head(x)
  # get time
  time <- ncvar_get(ncin,"time")
  bedrock  <- ncvar_get(ncin,"bedrock")
  bedrock_i=bedrock[,,1]
  elevation <- ncvar_get(ncin,"height")
  elevation_i=elevation[,,1]
  assignment_mask<- ncvar_get(ncin,"assignment_mask")
  assignment_mask_i=assignment_mask[,,1]
  ice_i = elevation_i-bedrock_i
  } else if (period=="LGM"){
    ncname <- 'LGM_topos'
    ncfname <- paste(ncname, ".cdf", sep = "")
    # open a NetCDF file to get vars
    ncin <- nc_open(ncfname)
    # print(ncin)
    # y <- ncvar_get(ncin,"y")
    # ny <- dim(y)
    # head(y)
    # x <- ncvar_get(ncin,"x")
    # nx <- dim(x)
    # head(x)
    # get time
    # time <- ncvar_get(ncin,"time")
    bedrock  <- ncvar_get(ncin,"BEDROCK")
    bedrock_i=bedrock[,]
    elevation <- ncvar_get(ncin,"TOPOGRAPHY")
    elevation_i=elevation[,]
    assignment_mask_i=elevation_i
    assignment_mask_i[]=0
    assignment_mask_i[elevation_i<0]=1
    ice_i = elevation_i-bedrock_i
    #rm(assignment_mask_i)
    rm(bedrock_i)
    rm(elevation)
    rm(bedrock)
    
    nc_close(ncin)
    rm(ncin,ncname, ncfname)
  }

#regions by geographical borders
setwd("/home/tobias/PhD/Programming/NEW/modeloutput/Analysis_scripts")
source("create_regions_GrIS.R")
regions_grad<-regions_gradient()

#region with straight borders
region_mask=array(0,c(281,165))
region_mask[10:80,0:60]=1
region_mask[10:80,60:120]=2
region_mask[80:160,0:60]=3
region_mask[80:160,60:100]=4
region_mask[80:110,100:150]=5
region_mask[110:160,100:120]=6
region_mask[160:220,60:100]=8
region_mask[160:270,10:60]=7
region_mask[160:270,100:150]=9
region_mask[220:270,60:100]=10

#elevational bands
elevation_bands=c(0,1000,2000,2500,3000,6000)


#specify alltitude and ocean borders for regions
ice_thicknessborder=100
region_mask[ice_i<ice_thicknessborder]=0
region_mask[assignment_mask_i==1]=NaN

regions_grad[ice_i<ice_thicknessborder]=0
regions_grad[assignment_mask_i==1]=NaN

#total ice sheet
cumulative_array=ice_i
cumulative_array[cumulative_array<ice_thicknessborder]=0

elevation_mask=assignment_mask_i
for (i in 1:(length(elevation_bands)-1)){
  elevation_mask[elevation_i>elevation_bands[i]]=i
}
elevation_mask[ice_i<ice_thicknessborder]=0
elevation_mask[assignment_mask_i==1]=NaN

# #amount of runs/files
 nstart=1
# n=5500
# #read MB data
# setwd("/home/tobias/PhD/Programming/NEW/modeloutput/")
# #setwd("/home/tobias/PhD/Programming/NEW/modeloutput/output")
# ncname <- "mass_balance_5500ensemble"
# ncfname <- paste(ncname, ".nc", sep = "")
# # open a NetCDF file to get vars
# ncin <- nc_open(ncfname)
# # print(ncin)
# MB <- ncvar_get(ncin,"mass_balance")
# nc_close(ncin)
# rm(ncin)
# rm(ncfname,ncname)
# nc_close(ncin)

 detach("package:chron", unload=TRUE)
 detach("package:RColorBrewer", unload=TRUE)
 detach("package:lattice", unload=TRUE)
 detach("package:ncdf4", unload=TRUE)
# Area calculations --------------------------------------------------
#calculate MB arrays:
 while (!is.null(dev.list()))  dev.off()
 Sys.sleep(10)
 gc()
MB[ice_i<ice_thicknessborder]=NaN

#cumulative mass balance:
MB_cumulative=array(NaN,ensemblesize)
MB_i_cumulative=MB
MB_i_cumulative[cumulative_array=0]=NaN
for (i in nstart:ensemblesize){
 
  MB_cumulative[i]=sum(MB_i_cumulative[,,i],na.rm=TRUE)
  i
  Area_cumulative=sum(colSums(!is.na(MB[,,1])))
}
rm(i,MB_i_cumulative)
gc()
Sys.sleep(10)
gc()
#elevational

# MB_elevation=matrix(NaN,nrow=n,ncol=(length(elevation_bands)-1))
# MB_elevation_cum=matrix(NaN,nrow=n,ncol=(length(elevation_bands)-1))
# Area_elevation=array(NaN,(length(elevation_bands)-1))
# for (i in 1:(length(elevation_bands)-1)){
#     MB_ele_i=MB
#     MB_ele_i[elevation_i<elevation_bands[i] | elevation_i>elevation_bands[i+1]]=NaN
#     #can be placed within the loop if area changes with run number i.e. height adjustment
#     Area_elevation[i]=sum(colSums(!is.na(MB_ele_i[,,1])))
#     for (k in nstart:n){        
#   MB_elevation[k,i]=sum(MB_ele_i[,,k],na.rm=TRUE)
#   i
#     }
# }
regions=max(elevation_mask[elevation_mask!=0],na.rm=TRUE)-min(elevation_mask[elevation_mask!=0],na.rm=TRUE)+1
MB_elevation=matrix(NaN,nrow=ensemblesize,ncol=regions)
Area_elevation=array(NaN,regions)
for (i in 1:regions){
  MB_ele_i=MB
  MB_ele_i[elevation_mask!=i]=NaN
  Area_elevation[i]=sum(colSums(!is.na(MB_ele_i[,,1])))
  for (k in nstart:ensemblesize){        
    MB_elevation[k,i]=sum(MB_ele_i[,,k],na.rm=TRUE)
    i
  }
}
gc()
Sys.sleep(10)
gc()
regions=max(elevation_mask[elevation_mask!=0],na.rm=TRUE)-min(elevation_mask[elevation_mask!=0],na.rm=TRUE)+1
MB_elevation_cum=matrix(NaN,nrow=ensemblesize,ncol=regions)
Area_elevation_cum=array(NaN,regions)
for (i in 1:regions){
  MB_ele_i=MB
  MB_ele_i[elevation_mask<=0||elevation_mask>i]=NaN
  Area_elevation_cum[i]=sum(colSums(!is.na(MB_ele_i[,,1])))
  for (k in nstart:ensemblesize){        
    MB_elevation_cum[k,i]=sum(MB_ele_i[,,k],na.rm=TRUE)
  }
}
rm(MB_ele_i)
gc()
gc()
Sys.sleep(10)
gc()
# 
# Area_elevation_cum=array(NA,(length(elevation_bands)-1))
# for (i in 2:(length(elevation_bands))){
#   MB_ele_i=MB
#   MB_ele_i[elevation_i>elevation_bands[i]]=NaN
#   Area_elevation_cum[i-1]=sum(colSums(!is.na(MB_ele_i[,,1])))
#   for (k in nstart:n){        
#     MB_elevation_cum[k,i-1]=sum(MB_ele_i[,,k],na.rm=TRUE)
#     i
#   }
# }

# rm(MB_ele_i)
#regional pure


regions=max(region_mask[region_mask!=0],na.rm=TRUE)-min(region_mask[region_mask!=0],na.rm=TRUE)+1
MB_regional=matrix(NaN,nrow=ensemblesize,ncol=regions)
Area_regional=array(NaN,regions)
for (i in 1:regions){
  MB_reg_i=MB
  MB_reg_i[region_mask!=i]=NaN
  Area_regional[i]=sum(colSums(!is.na(MB_reg_i[,,1])))
  for (k in nstart:ensemblesize){        
    MB_regional[k,i]=sum(MB_reg_i[,,k],na.rm=TRUE)
    i
  }
}
rm(MB_reg_i)
gc()
gc()
Sys.sleep(10)
gc()

regions=max(regions_grad[regions_grad!=0],na.rm=TRUE)-min(regions_grad[regions_grad!=0],na.rm=TRUE)+1
MB_regions_grad=matrix(NaN,nrow=ensemblesize,ncol=regions)
Area_regions_grad=array(NaN,regions)
for (i in 1:regions){
  MB_regions_grad_i=MB
  MB_regions_grad_i[regions_grad!=i]=NaN
  Area_regions_grad[i]=sum(colSums(!is.na(MB_regions_grad_i[,,1])))
  for (k in nstart:ensemblesize){        
    MB_regions_grad[k,i]=sum(MB_regions_grad_i[,,k],na.rm=TRUE)
    i
  }
}
rm(MB_regions_grad_i)
gc()
gc()
Sys.sleep(10)
gc()


region_calculation<-function(variablein,region_mask,ensemblesize){
  regions=max(region_mask[region_mask!=0],na.rm=TRUE)-min(region_mask[region_mask!=0],na.rm=TRUE)+1
  variableout=matrix(NaN,nrow=ensemblesize,ncol=regions)
  Area_out=array(NaN,regions)
  for (i in 1:regions){
    MB_reg_i=variablein
    MB_reg_i[region_mask!=i]=NaN
    Area_out[i]=sum(colSums(!is.na(MB_reg_i[,,1])))
    for (k in nstart:ensemblesize){        
      variableout[k,i]=sum(MB_reg_i[,,k],na.rm=TRUE)
      
    }
  }
  rm(MB_reg_i)
  gc()
  gc()
  Sys.sleep(10)
  gc()
  
  return_value <- list("area" = Area_out, "var_vec" = variableout,"mask"=region_mask)
  return(return_value)
}

# # #regional+elevation
# # # Testplots including GSA --------------------------------------------------
#  library(latex2exp)
#  library(scales)
# source('Analysis_scripts/Create_ensemble_matrix_for_analysis.R')
# # 
# # 
# # ##spare
# # ylimit_min=min(MB_cumulative/sum(Area_cumulative))
# # ylimit_max=max(MB_cumulative/sum(Area_cumulative))
# # plot(MB_cumulative/sum(Area_cumulative),xlab="", ylab="", ylim=c(ylimit_min,ylimit_max),col=rgb(0,0,0,alpha=0.2),main="cumulative")
# # par(new=TRUE)
# # plot(c(899,2868,4332),MB_cumulative[c(899,2868,4332)]/sum(Area_cumulative),col='red',xlab="", 
# #      ylab="", ylim=c(ylimit_min,ylimit_max),xlim=c(nstart,n))
# # 
# # i=5
# # minimum=array(NaN,5)
# # maximum=array(NaN,5)
# # 
# # for (i in 1:length(MB_elevation[1,])){minimum[i]=min(MB_elevation[,i]/Area_elevation[i])}
# # for (i in 1:length(MB_elevation[1,])){maximum[i]=max(MB_elevation[,i]/Area_elevation[i])}
# # ylimit_min=min(minimum)
# # ylimit_max=max(maximum)
# # colormap=(c("black","green","blue","orange","brown","grey"))
# # for (i in 1:length(MB_elevation[1,])){
# # 
# # plot(MB_elevation[,i]/Area_elevation[i],xlab="", ylab="", ylim=c(ylimit_min,ylimit_max),col=alpha(colormap[i],0.05),pch=i+12)
# # par(new=TRUE)
# # plot(c(899,2868,4332),(MB_elevation[c(899,2868,4332),i]/Area_elevation[i]),col=alpha(colormap[i]),xlab="", 
# #      ylab="", ylim=c(ylimit_min,ylimit_max),xlim=c(nstart,n),pch=20)
# # par(new=TRUE)
# # }
# # 
# 
# 
# # Plotting to PDF --------------------------------------------------
# 
# pdfname=paste("Cumulativ_MB_regional_sensitivity_.pdf",sep="")
# pdf(pdfname,10,7)
# #only for plotting change color order
# plotting_mask=region_mask
# plotting_mask[region_mask==7]=8
# plotting_mask[region_mask==8]=7
# plotting_mask[region_mask==1]=10
# plotting_mask[region_mask==10]=1
# regions=max(region_mask[region_mask!=0],na.rm=TRUE)-min(region_mask[region_mask!=0],na.rm=TRUE)+1
# x2labelparam=TeX('Par: $\\alpha_{nw}$ $\\alpha_{wt}$  $\\alpha_{ic}$  $D_{sf}$  $D_{lf/sf}$  $e_{air}$ $Q_L$ $\\alpha_{mo}$ $lwc$')
# layout(matrix(c(1:7,11,8:10,11), nrow = 3, ncol = 4, byrow = TRUE))
# par(mar=c(2,2,2,0.5), oma=c(1,1,3,1))
# par(xpd=TRUE)
# for (i in 1:regions){
#   tell(xx,MB_regional[,i])
#   plot(xx,main=paste(i),showlegend = FALSE, xlab="test")
#   # p=layout(showlegend = FALSE)
#   title(main=paste("region number ",i))
#   legend(0.3, -0.05, x2labelparam, box.col = "white", bg = "white", adj = 0.2,cex=1.19)
#   rect(-1,-0.2,0.5,-0.1,col="white",border = "white")
# }
# #contour(t(region_mask[,,1]),xaxt='n',ann=FALSE,yaxt='n',ann=FALSE)
# cols = rev(colorRampPalette(c('black','grey'))(16))
# image(as.matrix(t(plotting_mask)),col=cols,axes=FALSE) 
# mtext("1", side = 1, line = -5.5, outer = FALSE,cex=1., at=0.34,col='white')
# mtext("2", side = 1, line = -5.5, outer = FALSE,cex=1., at=0.45,col='white')
# mtext("3", side = 1, line = -13, outer = FALSE,cex=1., at=0.34,col='white')
# mtext("4", side = 1, line = -13, outer = FALSE,cex=1., at=0.45,col='white')
# mtext("5", side = 1, line = -10.5, outer = FALSE,cex=1., at=0.66,col='white')
# mtext("6", side = 1, line = -13, outer = FALSE,cex=1., at=0.66,col='white')
# mtext("7", side = 1, line = -20, outer = FALSE,cex=1., at=0.3,col='white')
# mtext("8", side = 1, line = -20, outer = FALSE,cex=1., at=0.45,col='white')
# mtext("9", side = 1, line = -20, outer = FALSE,cex=1., at=0.66,col='white')
# mtext("10", side = 1, line = -24, outer = FALSE,cex=1., at=0.45,col='white')
# rm(plotting_mask)
# dev.off() 
# 
# 
# 
# pdfname=paste("Cumulativ_MB_elevational.pdf",sep="")
# pdf(pdfname,10,7)
# #only for plotting change color order
# plotting_mask=assignment_mask_i
# # x2labelparam=TeX('Par:  $\\alpha_{nw} \\cdot$ $\\alpha_{wt} \\cdot$  $\\alpha_{ic} \\cdot$  $D_{sf}$  $D_{lf/sf}$  $e_{air} \\cdot$ $Q_L \\cdot \\alpha_{m} \\cdot lwc$')
# x2labelparam=TeX('Par: $\\alpha_{nw}$ $\\alpha_{wt}$  $\\alpha_{ic}$  $D_{sf}$  $D_{lf/sf}$  $e_{air}$ $Q_L$ $\\alpha_{mo}$ $lwc$')
# x3labelparam=TeX('$\\alpha_{nw}$ $\\alpha_{wt}$  $\\alpha_{ic}$  $D_{sf}$  $D_{lf/sf}$  $e_{air}$ $Q_L$ $\\alpha_{mo}$ $lwc$')
# for (i in 1:(length(elevation_bands)-1)){
#   plotting_mask[elevation_i>elevation_bands[i]]=i
# }
# plotting_mask[is.nan(MB[,,1])]=0
# plotting_mask[assignment_mask_i==1]=NaN
# layout(matrix(c(1:7,11,8:10,11), nrow = 3, ncol = 4, byrow = TRUE))
# par(mar=c(2,2,2,0.5), oma=c(1,1,3,1))
# #draw things outside
# par(xpd=TRUE)
# for (i in 1:(length(elevation_bands)-1)){
#   tell(xx,MB_elevation[,i])
#   plot(xx,main=paste(i),showlegend = FALSE, xlab="test")
#   # p=layout(showlegend = FALSE)
#   title(main=paste(elevation_bands[i],"-",elevation_bands[i+1]),"m")
#   legend(0.3, -0.05, x2labelparam, box.col = "white", bg = "white", adj = 0.2,cex=1.19)
#   rect(-1.2,-0.2,0.5,-0.1,col="white",border = "white")
# }
# for (i in 2:(length(elevation_bands))){
#   tell(xx,MB_elevation_cum[,i-1])
#   plot(xx,main=paste((length(elevation_bands)-1)+i-1),showlegend = FALSE, xlab="test")
#   # p=layout(showlegend = FALSE)
#   title(main=paste("0 -",elevation_bands[i],"m"))
#   legend(0.3, -0.05, x2labelparam, box.col = "white", bg = "white", adj = 0.2,cex=1.19)
#   rect(-1.2,-0.2,0.5,-0.1,col="white",border = "white")
# }
# #contour(t(region_mask[,,1]),xaxt='n',ann=FALSE,yaxt='n',ann=FALSE)
# cols = rev(colorRampPalette(c('black','grey'))(16))
# image(as.matrix(t(plotting_mask)),col=cols,axes=FALSE) 
# 
# mtext("1000+", side = 2, line = -6, outer = FALSE,cex=0.8, at=0.34,col='white')
# mtext("3000+", side = 1, line = -16, outer = FALSE,cex=.8, at=0.6,col='white')
# mtext("2500+", side = 1, line = -19, outer = FALSE,cex=.8, at=0.48,col='white')
# mtext("2000+", side = 1, line = -22.4, outer = FALSE,cex=.8, at=0.45,col='white')
# rm(plotting_mask)
# dev.off() 