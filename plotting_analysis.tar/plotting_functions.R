#further analysis
##create scatter plots, area plots etc.
# Open a pdf file
#read netcdf ensemble file
library(chron)
library(RColorBrewer)
library(lattice)
library(ncdf4)
library(sensitivity)
library(TeachingDemos)
library(latex2exp)
library(ggplot2)

#setwd("/home/tobias/PhD/Programming/NEW/modeloutput/ensemble_00001_a_new0775_a_wet0575_a_i035_D_sf15_D_lf085_eps075_latent0_a_mod3_lwc012018_06_09_1300_24/")
setwd("/home/tobias/PhD/Programming/NEW/modeloutput/")
#setwd("/home/tobias/PhD/Programming/NEW/modeloutput/output")
ncname <- "CENTURY_00001"
ncfname <- paste(ncname, ".nc", sep = "")
# open a NetCDF file to get vars
ncin <- nc_open(ncfname)
# print(ncin)
y <- ncvar_get(ncin,"y")
ny <- dim(y)
head(y)
x <- ncvar_get(ncin,"x")
nx <- dim(x)
head(x)
# get time
time <- ncvar_get(ncin,"time")
layer <- ncvar_get(ncin,"layer")

ncname <- "mass_balance_5500ensemble"
ncfname <- paste(ncname, ".nc", sep = "")
# open a NetCDF file to get vars
ncin <- nc_open(ncfname)
# print(ncin)
MB2 <- ncvar_get(ncin,"mass_balance")
#firn_temp <- ncvar_get(ncin,"10m_snowtemp")
source('/home/tobias/PhD/Programming/NEW/modeloutput/Analysis_scripts/Create_ensemble_matrix_for_analysis.R')
attach(mtcars)


# start plot ---------------------------------
# 2. Create a plot
# for (px in c(40,60,100,120,140,160,180,200)) {
#   for (py in c(50,60,70,100,120)) {
  #mass_balance, vector of ensemble, length of ensemble, where, type=LGM, ERAi
    plot_scatters <- function(variable,vector,ensemble_size,location,type){
    pdfname=paste("scatters/",type,"/",variable,"_",location,".pdf",sep="")
    pdf(pdfname) 
    
    par(mfrow=c(3,3), mar=c(2,2,2,0.5), oma=c(2,1,3,1))#mai = c(1, 0.25, 0.25, 0.25))
    
    #test=c(1:898,900:2867,2869:4331,4333:5500) #exclude the three low runs in plot
    ylimit_min=min(vector)
    ylimit_max=max(vector)
    plot(samp[,1],vector, main="new snow",pch=16,col=rgb(0,0,0,alpha=0.2),
         xlab="", ylab="", ylim=c(ylimit_min,ylimit_max))
    plot(samp[,2],vector, main="wet snow",col=rgb(0,0,0,alpha=0.2),
         xlab=" ", ylab="", pch=16, ylim=c(ylimit_min,ylimit_max))
    plot(samp[,3],vector, main="ice",col=rgb(0,0,0,alpha=0.2),
         xlab=" ", ylab="", pch=16, ylim=c(ylimit_min,ylimit_max))
    plot(samp[,4],vector, main="Dsh",col=rgb(0,0,0,alpha=0.2),
         xlab=" ", ylab="", pch=16, ylim=c(ylimit_min,ylimit_max))
    plot(samp[,5],vector, main="Dlf/Dsh",col=rgb(0,0,0,alpha=0.2),
         xlab=" ", ylab="", pch=16,ylim=c(ylimit_min,ylimit_max))
    plot(samp[,6],vector, main="eps",col=rgb(0,0,0,alpha=0.2),
         xlab=" ", ylab="", pch=16, ylim=c(ylimit_min,ylimit_max))
    plot(samp[,7],vector, main="QL on/off",col=rgb(0,0,0,alpha=0.2),
         xlab="mass balance ", ylab="", pch=16,ylim=c(ylimit_min,ylimit_max))
    plot(samp[,8], vector,main="albedo module",col=rgb(0,0,0,alpha=0.2),
         xlab="mass balance ", ylab="", pch=16,ylim=c(ylimit_min,ylimit_max))
    plot(samp[,9],vector, main="lwc",col=rgb(0,0,0,alpha=0.2),
         xlab="mass balance ", ylab="", pch=16,ylim=c(ylimit_min,ylimit_max))
    # title(paste("Point:",px,",",py), outer=TRUE)
    mtext(paste(location,type), side = 3, line = 0, outer = TRUE)
    mtext(variable, side = 3, line = -50, outer = TRUE)
    # Close the pdf file
    dev.off() 
  }

 # old_boxplots -------------------------------------------------------
pdfname=paste("boxplots/box_albedo_module.pdf",sep="")
albedo_boxplots <- function(pdfname){
pdf(pdfname)
attach(mtcars)
par(mfrow=c(3,3), mar=c(2,2,2,0.5), oma=c(2,1,3,1))
#albedo module histograms
xvector=c(40,60,80,80,120,120,150,180,200)
yvector=c(60,60,60,90,80,110,80,80,80)
for (i in 1:9) {
value=MB[xvector[i],yvector[i],]
numbers=samp[,8]
names=array("default",dim=5500)
names=replace(names, numbers==1, "Const")
names=replace(names, numbers==3, "Oerlemans")
names=replace(names, numbers==4, "Aoki")
names=replace(names, numbers==5, "Bougamont")
data=data.frame(names,value)


# Calculate proportion of each level
proportion=table(data$names)/nrow(data)

#Draw the boxplot, with the width proportionnal to the occurence !
boxplot(data$value ~ data$names , width=proportion , col=c("orange" , "seagreen"),main=paste(xvector[i],"_",yvector[i],sep="")
        ,range=1, outline=FALSE)


}
dev.off() 
}

# mixed plots --------------------------------------------------
attach(mtcars)
#mixed plots
# for (px in c(40,60,100,120,140,160,180,200)) {
#   for (py in c(50,60,70,100,120)) {
    plot_scatters <- function(variable,vector,ensemble_size,location,type){
    pdfname=paste("scatters/",type,"/","mixed",variable,"_",location,".pdf",sep="")
    pdf(pdfname) 
    
    par(mfrow=c(3,3), mar=c(2,2,2,0.5), oma=c(2,1,3,1))#mai = c(1, 0.25, 0.25, 0.25))
    
    # test=c(1:898,900:2867,2869:4331,4333:5500) #exclude the three low runs in plot
    ylimit_min=min(vector)
    ylimit_max=max(vector)
    
    value=vector
    numbers8=samp[,8]
    names8=array("default",dim=ensemble_size)
    names8=replace(names8, numbers8==1, "Const")
    names8=replace(names8, numbers8==3, "Oerle.")
    names8=replace(names8, numbers8==4, "Aoki")
    names8=replace(names8, numbers8==5, "Boug.")
    data8=data.frame(names8,value)
    numbers7=samp[,7]
    names7=array("default",dim=ensemble_size)
    names7=replace(names7, numbers7==0, "QL off")
    names7=replace(names7, numbers7==1, "QL on")
    data7=data.frame(names7,value)
    
    # Calculate proportion of each level
    proportion7=table(data7$names7)/nrow(data7)
    proportion8=table(data8$names8)/nrow(data8)
    #Draw the boxplot, with the width proportionnal to the occurence !
    
    
    plot(samp[,1],vector, main="new snow",pch=16,col=rgb(0,0,0,alpha=0.2),
         xlab="", ylab="", ylim=c(ylimit_min,ylimit_max))
    plot(samp[,2],vector, main="wet snow",col=rgb(0,0,0,alpha=0.2),
         xlab=" ", ylab="", pch=16, ylim=c(ylimit_min,ylimit_max))
    plot(samp[,3],vector, main="ice",col=rgb(0,0,0,alpha=0.2),
         xlab=" ", ylab="", pch=16, ylim=c(ylimit_min,ylimit_max))
    plot(samp[,4],vector, main="Dsh",col=rgb(0,0,0,alpha=0.2),
         xlab=" ", ylab="", pch=16, ylim=c(ylimit_min,ylimit_max))
    plot(samp[,5],vector, main="Dlh/Dsh",col=rgb(0,0,0,alpha=0.2),
         xlab=" ", ylab="", pch=16,ylim=c(ylimit_min,ylimit_max))
    plot(samp[,6],vector, main="eps",col=rgb(0,0,0,alpha=0.2),
         xlab=" ", ylab="", pch=16, ylim=c(ylimit_min,ylimit_max))
    boxplot(data7$value ~ data7$names7 , width=proportion7 ,
            main="QL",range=1, ylim=c(ylimit_min,ylimit_max))
    boxplot(data8$value ~ data8$names8 , width=proportion8 ,main="albedo module"
            ,range=1, outline=FALSE)
    plot(samp[,9],vector, main="lwc",col=rgb(0,0,0,alpha=0.2),
         xlab="mass balance ", ylab="", pch=16,ylim=c(ylimit_min,ylimit_max))
    # title(paste("Point:",px,",",py), outer=TRUE)
    mtext(paste("Point: x=",px,", y=",py), side = 3, line = 0, outer = TRUE)
    mtext(variable, side = 3, line = -50, outer = TRUE)
    # Close the pdf file
    dev.off() 
}




#  plot exeption runs ERAi ------------------------------------------------------
pdfname=paste("Individual_runs/MB_100years_run-",899,"-",2868,"-",4332,".pdf",sep="")
pdf(pdfname)

#attach(mtcars)
par(mfrow=c(1,3), mar=c(20,2,2,0.5), oma=c(2,1,3,1))
for (i in c(899,2868,4332)){
  #squishplot(xlim=c(0,165),ylim=c(0,281))
  x1labelparam=paste(sprintf("%.2f",round(samp[i,1],2)),sprintf("%.2f",round(samp[i,2],2)),sprintf("%.2f",round(samp[i,3],2))
                     ,sprintf("%.2f",round(samp[i,4],1)),sprintf("%.2f",round(samp[i,5],2)),sprintf("%.2f",round(samp[i,6],2))
                     ," ",round(samp[i,7],2)," ",round(samp[i,8],2)," ",sprintf("%.2f",round(samp[i,9],2)))
  x2labelparam=TeX('$\\alpha_{nw} \\cdot$ $\\alpha_{wt} \\cdot$  $\\alpha_{ic} \\cdot$  $D_{sh} \\cdot$  $D_{lh/sh}$  $e_{air} \\cdot$ $Q_L$  $\\alpha_{m}$  $lwc$')
  # var=matrix(c(x1labelparam,x2labelparam),nrow=2,ncol=1)
  contour(t(MB[,,i]), xaxt='n',ann=FALSE,yaxt='n',ann=FALSE,main=paste("run ",i),mgp = c(1, 1, 0),xlab=x1labelparam)
  #squishplot(xlim=c(0,165),ylim=c(0,281)
  
  mtext(x2labelparam, side = 1, line = 2.3, outer = FALSE,cex=0.7)
}
mtext(paste("Mass balance of the three most negative runs"), side = 3, line = 0, outer = TRUE)
dev.off()

#individual ones
for (i in c(899,2868,4332)){
  pdfname=paste("Individual_runs/MB_100years_run-",i,".pdf",sep="")
  pdf(pdfname) 
  squishplot(xlim=c(0,165),ylim=c(0,281))
  contour(t(MB[,,i]),xaxt='n', ann=FALSE,yaxt='n',ann=FALSE)
  #        plot.axes = { axis(1, seq(0, 165, by = 15)) 
  #          axis(2, seq(0, 281, by = 15), line=-3.3) })
  dev.off() 
}


# testing --------------------------------------------------------------------
# plotting

# plotting scatter plot,  ?par see fig, par will position your scatter plot
# parameters are set so that we can provide space for boxplot in margin
boxscatter_plot<-function(px,py){
dev.new()
test=c(1:898,900:2867,2869:4331,4333:5500) #exclude the three low runs in plot
ylimit_min=min(MB[px,py,test])
ylimit_max=max(MB[px,py,test])
par(fig=c(0,0.8,0,0.8))
plot(samp[,9],MB[px,py,], main="lwc",col=rgb(0,0,0,alpha=0.2),
     xlab="mass balance ", ylab="", pch=16,ylim=c(ylimit_min,ylimit_max))

# now plotting first boxplot, in margin, you might need to change
# the numbers in parameters where you  to put the boxplots.
par(fig=c(0,0.8,0.55,1), new=TRUE)
boxplot(samp[,9], horizontal=TRUE, col = "red", axes=FALSE)

# now plotting second boxplot, in margin
par(fig=c(0.65,1,0,0.8),new=TRUE)
boxplot(MB[px,py,], col = "blue", axes=FALSE)
# just giving title to the plot
mtext("Scatterplot with boxplot at margin", side=3, outer=TRUE, line=-3)
}





# quantiles function -------------------------------------------------------------------------
std_quantiles = c(0.01,0.05,0.1,0.25,0.33,0.5,0.66,0.75,0.9,0.95,0.99)
f <- function(x) {
  r <- quantile(x, probs = c(0.05, 0.25,0.33, 0.5, 0.66, 0.75, 0.95),na.rm=TRUE)
  names(r) <- c("ymin", "25","33", "middle","66", "75", "ymax")
  r
}
o <- function(x) {
  subset(x, x < quantile(x,probs=std_quantiles[2],na.rm=TRUE) | quantile(x,probs=std_quantiles[10],na.rm=TRUE) < x)
}








# plot_ensemble function --------------------------------------------------------
plot_ensemble <- function(pdfname,MBvec,pointexclude,samp){

pdf(pdfname)
vec=c('a','b','c','d','e','f','g','h','i')
parameter_vec=c(TeX('$\\alpha_{nw}$'),TeX('$\\alpha_{wt}$'),TeX('$\\alpha_{ic}$'),TeX('$D_{sh}$'),
                TeX('$D_{lf/sh}$'),TeX('$e_{air}$'),TeX('$Q_L$'),TeX('$\\alpha_{m}$'),
                TeX('$lwc$'))
parameter_vec=c(TeX('$\\alpha_{fs}$'),TeX('$\\alpha_{fi}$'),TeX('$\\alpha_{i}$'),TeX('$D_{sh}$'),
                TeX('$r_{lh/sh}$'),TeX('$\\epsilon_{atm}$'),TeX('$\\chi_{QL}$'),TeX('$\\chi_{\\alpha}$'),
                TeX('$\\zeta_{max}$'))

par(mfrow=c(3,3), mar=c(2,1.5,2,0), oma=c(2,3,1,1))#mai = c(1, 0.25, 0.25, 0.25))
for (i in 1:6){

shift=(max(samp[,i])-min(samp[,i]))/20/2
sequence=seq(min(samp[,i]),max(samp[,i]),length.out=20)
lengthofplot=length(sequence)-1
df<-data.frame(samp[,i],MBvec)
df$samp...i. <- cut(df$samp...i., breaks = sequence)

quantileline=matrix(0,20,7)
mean_val=matrix(NA,20,1)
for (l in 1:19){
quantileline[l,]=f(df$MBvec[df$samp...i.==levels(df$samp...i.)[l]])
mean_val[l,1]=mean(df$MBvec[df$samp...i.==levels(df$samp...i.)[l]],na.rm=TRUE)
}

yrange=c(sort(df$MBvec,partial=pointexclude)[pointexclude],sort(df$MBvec,partial=length(df$MBvec)-pointexclude)[length(df$MBvec)-pointexclude])

# dev.new()
if (i==1|i==4){
plot(sequence[1:lengthofplot]+shift,quantileline[1:lengthofplot,4], ylim=yrange,ylab="mass balance",col="white",sub=parameter_vec[i])
}else{
  plot(sequence[1:lengthofplot]+shift,quantileline[1:lengthofplot,4], ylim=yrange,ylab="mass balance",col="white",yaxt='n')
}
#lines(seq(min(samp[,i]),max(samp[,i]),length.out=25),my_df$middle)
#lines(seq(min(samp[,i]),max(samp[,i]),length.out=25),my_df$upper)  levels(hey$samp...i.)[2]
polygon(c(sequence[1:lengthofplot]+shift, rev(sequence[1:lengthofplot]+shift)), c(quantileline[1:lengthofplot,1], rev(quantileline[1:lengthofplot,7])), col = "grey80", border = NA)
polygon(c(sequence[1:lengthofplot]+shift, rev(sequence[1:lengthofplot]+shift)), c(quantileline[1:lengthofplot,2], rev(quantileline[1:lengthofplot,6])), col = "grey60", border = NA)
polygon(c(sequence[1:lengthofplot]+shift, rev(sequence[1:lengthofplot]+shift)), c(quantileline[1:lengthofplot,3], rev(quantileline[1:lengthofplot,5])), col = "grey40", border = NA)
# polygon(c(sequence, rev(seq(min(samp[,i])
#                                                                   ,max(samp[,i]),length.out=20))), c(my_df$ymin, rev(my_df$ymax)), col = "grey70", border = NA)
# polygon(c(sequence, rev(seq(min(samp[,i])
#                                                                   ,max(samp[,i]),length.out=20))), c(my_df$lower, rev(my_df$upper)), col = "grey30", border = NA)
xlimits=par('usr')[1:2]
valuevec=matrix(NA,19,55)
lines(sequence[1:lengthofplot]+shift,quantileline[1:lengthofplot,4],axes=FALSE)
for(k in 1:19){
  par(new=TRUE)
values=o(df$MBvec[df$samp...i.==levels(df$samp...i.)[k]])
# valuevec[k,1:length(values)]=values
location=values
location[]=c(sequence[k])
plot(location+shift, values, ylim=yrange,xlim=xlimits,ylab="",xlab="test",xaxs='i',pch=20,axes=FALSE,col=alpha("grey90",0.2))
par(new=TRUE)
plot(sequence+shift,mean_val,ylim=yrange,xlim=xlimits,ylab="",xlab="test",xaxs='i',pch=".",axes=FALSE,col=alpha("black",0.9))
}
mtext(vec[i], side=1, line=-2,adj=0.90, outer=FALSE,cex=0.8)
if (i>3){
title(main=parameter_vec[i-3])
}
rm(df,location,values,sequence,shift,lengthofplot,xlimits)
}

i=7
df<-data.frame(samp[,i],MBvec)
quantileline=matrix(0,2,7)
mean_val=matrix(NA,2,1)
for (l in 1:2){
  quantileline[l,]=f(df$MBvec[df$samp...i.==l-1])
  mean_val[l,1]=mean(df$MBvec[df$samp...i.==l-1],na.rm=TRUE)
}
plot(1:2,quantileline[,2], ylim=yrange,ylab="mass balance",col="white",xlim=c(0.5,2.5),xaxt='n', ann=FALSE)

for (j in 1:2){
  polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,1],quantileline[j,1]),rev(c(quantileline[j,7],quantileline[j,7]))), col = "grey80", border = NA,ylab="",xlab="")
  polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,2],quantileline[j,2]),rev(c(quantileline[j,6],quantileline[j,6]))), col = "grey60", border = NA,ylab="",xlab="")
  polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,3],quantileline[j,3]),rev(c(quantileline[j,5],quantileline[j,5]))), col = "grey40", border = NA,ylab="",xlab="")
  lines(c(j-0.4,j+0.4),c(quantileline[j,4],quantileline[j,4]),ylab="",xlab="",axes=FALSE)
  values=o(df$MBvec[df$samp...i.==j-1])
  location=values
  location[]=j
  xlimits=par('usr')[1:2]
  par(new=TRUE)
  plot(location, values, ylim=yrange,xlim=xlimits,ylab="TeX('$\\chi_{\\alpha}$')",xlab="",xaxs='i',pch=20,axes=FALSE,col=alpha("grey90",0.2))
  par(new=TRUE)
  plot(j,mean_val[j,1],ylim=yrange,xlim=xlimits,ylab="TeX('$\\chi_{\\alpha}$')",xlab="",xaxs='i',pch=".",axes=FALSE,col=alpha("black",0.9))
}
mtext('g', side=1, line=-2,adj=0.90, outer=FALSE,cex=0.8)
quantity=c("QL off","QL on")
axis(1,at=1:2,labels=quantity,cex.axis=0.7)
if (i>3){
  title(main=parameter_vec[i-3])
}


i=8
df<-data.frame(samp[,i],MBvec)
df$samp...i.[df$samp...i.==5]=2
quantileline=matrix(0,4,7)
mean_val=matrix(NA,4,1)
for (l in 1:4){
  quantileline[l,]=f(df$MBvec[df$samp...i.==l])
  mean_val[l,1]=mean(df$MBvec[df$samp...i.==l],na.rm=TRUE)
}
plot(1:4,quantileline[,4], ylim=yrange,ylab="mass balance",main=parameter_vec[i],col="white",xlim=c(0.5,4.5),xaxt='n', ann=FALSE,yaxt='n')

for (j in 1:4){
polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,1],quantileline[j,1]),rev(c(quantileline[j,7],quantileline[j,7]))), col = "grey80", border = NA,ylab="",xlab="")
  polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,2],quantileline[j,2]),rev(c(quantileline[j,6],quantileline[j,6]))), col = "grey60", border = NA,ylab="",xlab="")
  polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,3],quantileline[j,3]),rev(c(quantileline[j,5],quantileline[j,5]))), col = "grey40", border = NA,ylab="",xlab="")
  lines(c(j-0.4,j+0.4),c(quantileline[j,4],quantileline[j,4]),ylab="",xlab="",axes=FALSE)
  values=o(df$MBvec[df$samp...i.==j])
  location=values
  location[]=j
  xlimits=par('usr')[1:2]
  par(new=TRUE)
  plot(location, values, ylim=yrange,xlim=xlimits,ylab="",xlab="",xaxs='i',pch=20,axes=FALSE,col=alpha("grey90",0.2))
  par(new=TRUE)
  plot(j,mean_val[j,1],ylim=yrange,xlim=xlimits,ylab="",xlab="",xaxs='i',pch=".",axes=FALSE,col=alpha("black",0.9))
}
mtext('h', side=1, line=-2,adj=0.90, outer=FALSE,cex=0.8)
quantity=c("cons","Boug","Oerl","Aoki")
axis(1,at=1:4,labels=quantity,cex.axis=0.7)
if (i>3){
  title(main=parameter_vec[i-3])
}

for (i in 9:9){
  
  shift=(max(samp[,i])-min(samp[,i]))/20/2
  sequence=seq(min(samp[,i]),max(samp[,i]),length.out=20)
  lengthofplot=length(sequence)-1
  df<-data.frame(samp[,i],MBvec)
  df$samp...i. <- cut(df$samp...i., breaks = sequence)
  
  quantileline=matrix(0,20,7)
  mean_val=matrix(NA,20,1)
  for (l in 1:19){
    quantileline[l,]=f(df$MBvec[df$samp...i.==levels(df$samp...i.)[l]])
    mean_val[l,1]=mean(df$MBvec[df$samp...i.==levels(df$samp...i.)[l]],na.rm=TRUE)
  }
  

  
  # dev.new()
  plot(sequence[1:lengthofplot]+shift,quantileline[1:lengthofplot,4], ylim=yrange,ylab="mass balance",col="white",yaxt='n')
  #lines(seq(min(samp[,i]),max(samp[,i]),length.out=25),my_df$middle)
  #lines(seq(min(samp[,i]),max(samp[,i]),length.out=25),my_df$upper)  levels(hey$samp...i.)[2]
  polygon(c(sequence[1:lengthofplot]+shift, rev(sequence[1:lengthofplot]+shift)), c(quantileline[1:lengthofplot,1], rev(quantileline[1:lengthofplot,7])), col = "grey80", border = NA,ylab="",xlab="")
  polygon(c(sequence[1:lengthofplot]+shift, rev(sequence[1:lengthofplot]+shift)), c(quantileline[1:lengthofplot,2], rev(quantileline[1:lengthofplot,6])), col = "grey60", border = NA,ylab="",xlab="")
  polygon(c(sequence[1:lengthofplot]+shift, rev(sequence[1:lengthofplot]+shift)), c(quantileline[1:lengthofplot,3], rev(quantileline[1:lengthofplot,5])), col = "grey40", border = NA,ylab="",xlab="")
  # polygon(c(sequence, rev(seq(min(samp[,i])
  #                                                                   ,max(samp[,i]),length.out=20))), c(my_df$ymin, rev(my_df$ymax)), col = "grey70", border = NA)
  # polygon(c(sequence, rev(seq(min(samp[,i])
  #                                                                   ,max(samp[,i]),length.out=20))), c(my_df$lower, rev(my_df$upper)), col = "grey30", border = NA)
  xlimits=par('usr')[1:2]
  valuevec=matrix(NA,19,55)
  lines(sequence[1:lengthofplot]+shift,quantileline[1:lengthofplot,4],ylab="",xlab="",axes=FALSE)
  for(k in 1:19){
    par(new=TRUE)
    values=o(df$MBvec[df$samp...i.==levels(df$samp...i.)[k]])
    # valuevec[k,1:length(values)]=values
    location=values
    location[]=c(sequence[k])
    plot(location+shift, values, ylim=yrange,xlim=xlimits,ylab="",xlab="",xaxs='i',pch=20,axes=FALSE,col=alpha("grey90",0.2))
    par(new=TRUE)
    plot(sequence+shift,mean_val,ylim=yrange,xlim=xlimits,ylab="",xlab="",xaxs='i',pch=".",axes=FALSE,col=alpha("black",0.9))
    }
  rm(df,location,values,sequence,shift,lengthofplot,xlimits)
}
if (i>3){
  title(main=parameter_vec[i-3])
}
mtext(~paste("surface mass balance ", "(kgm"^-2,')'), side=2, line=1, outer=TRUE)
mtext(parameter_vec[9], side=1, line=1,adj=0.87, outer=TRUE,cex=0.8)
mtext(parameter_vec[8], side=1, line=1,adj=0.52, outer=TRUE,cex=0.8)
mtext(parameter_vec[7], side=1, line=1,adj=0.17, outer=TRUE,cex=0.8)
# mtext('a', side=1, line=1,adj=0.27, outer=FALSE,cex=0.8)
# mtext('b', side=1, line=1,adj=0.62, outer=FALSE,cex=0.8)
mtext('i', side=1, line=-2,adj=0.90, outer=FALSE,cex=0.8)
# mtext('d', side=1, line=1,adj=0.27, outer=FALSE,cex=0.8)
# mtext('e', side=1, line=1,adj=0.62, outer=FALSE,cex=0.8)
# mtext('f', side=1, line=1,adj=0.97, outer=FALSE,cex=0.8)
# mtext('g', side=1, line=1,adj=0.27, outer=FALSE,cex=0.8)
# mtext('h', side=1, line=1,adj=0.62, outer=FALSE,cex=0.8)
# mtext('i', side=1, line=1,adj=0.97, outer=FALSE,cex=0.8)
dev.off()
}


# plot parameter per page -----
plot_parameter_sensitivity <- function(pdfinname,MB_veci,MB_cumu,parameter,pointexclude,insamp,map){
  parameter_names=c("a_new","a_wet","a_ice","Dsh","ratio","e_air","QL","albmod","lwc")
  pdfname=paste(pdfinname,"_",parameter_names[parameter],".pdf",sep="")
  pdf(pdfname)
  # pngname=paste(pdfinname,"_",parameter_names[parameter],".png",sep="")
  # png(pngname)
  # insamp=insamp
  parameter_vec=c(TeX('$\\alpha_{fs}$'),TeX('$\\alpha_{fi}$'),TeX('$\\alpha_{i}$'),TeX('turbulent exchange coefficient [$D_{sh}$] $(W kg K^{-1})$'),
                  TeX('$r_{lh/sh}$'),TeX('$\\epsilon_{atm}$'),TeX('$Q_L{on/off}$'),TeX('$\\alpha_{m}$'),
                  TeX('$\\zeta_{max}$'))
  parameter_vec=c(TeX('$\\alpha_{fs}$'),TeX('$\\alpha_{fi}$'),TeX('$\\alpha_{i}$'),TeX('$D_{sh}$'),
                  TeX('$r_{lh/sh}$'),TeX('$\\epsilon_{atm}$'),TeX('$\\chi_{QL}$'),TeX('$\\chi_{\\alpha}$'),
                  TeX('$\\zeta_{max}$'))
  parameter_vec=c(TeX('$\\alpha_{fs}$'),TeX('$\\alpha_{fi}$'),TeX('$\\alpha_{i}$'),TeX('$D_{sh} \ \ (Wm^{-2}K^{-1})$'),
                  TeX('$r_{lh/sh}$'),TeX('$\\epsilon_{atm}$'),TeX('$\\chi_{QL}$'),TeX('$\\chi_{\\alpha}$'),
                  TeX('$\\zeta_{max}$'))
  
  if ((length(MB_veci[1,]))<2){par(mfrow=c(1,3), mar=c(2,2,2,0.5), oma=c(3,3,1,1))}
  else if (length(MB_veci[1,])==2){par(mfrow=c(2,2), mar=c(2,2,2,0.5), oma=c(3,3,1,1))}
  else if (length(MB_veci[1,])<6){par(mfrow=c(2,3), mar=c(2,2,2,0.5), oma=c(3,3,1,1))}
  else if (length(MB_veci[1,])<9){par(mfrow=c(3,3), mar=c(2,2,2,0.5), oma=c(3,3,1,1))}
  else if (length(MB_veci[1,])<12){par(mfrow=c(3,4), mar=c(0.5,2,1.5,0.5), oma=c(4,3,3,1))}
  else if (length(MB_veci[1,])<16){par(mfrow=c(4,4), mar=c(0.5,2,1.5,0.5), oma=c(4,3,3,1))}
  else if (length(MB_veci[1,])<20){par(mfrow=c(4,5), mar=c(0.5,2,1.5,0.5), oma=c(4,3,3,1))}
  else if (length(MB_veci[1,])<25){par(mfrow=c(5,5), mar=c(2,2,2,0.5), oma=c(3,3,1,1))}
  else if (length(MB_veci[1,])<30){par(mfrow=c(5,6), mar=c(2,2,2,0.5), oma=c(3,3,1,1))}
  else if (length(MB_veci[1,])<36){par(mfrow=c(6,6), mar=c(2,2,2,0.5), oma=c(3,3,1,1))}
  else {par(mfrow=c(8,8), mar=c(2,2,2,0.5), oma=c(2,1,3,1))}
  i=parameter
  if (i<7 | i==9){
  for (j in 1:length(MB_veci[1,])){
    MBvec=MB_veci[,j]
    shift=(max(insamp[,i])-min(insamp[,i]))/20/2
    sequence=seq(min(insamp[,i]),max(insamp[,i]),length.out=20)
    lengthofplot=length(sequence)-1
    # print(length(MBvec))
    # print(length(insamp[,i]))
    df<-data.frame(insamp[,i],MBvec)
    # print("after")
    df$insamp...i. <- cut(df$insamp...i., breaks = sequence)
    
    quantileline=matrix(0,20,7)
    mean_val=matrix(NA,20,1)
    for (l in 1:19){
      quantileline[l,]=f(df$MBvec[df$insamp...i.==levels(df$insamp...i.)[l]])
      mean_val[l,1]=mean(df$MBvec[df$insamp...i.==levels(df$insamp...i.)[l]],na.rm=TRUE)
    }
    
    yrange=c(sort(df$MBvec,partial=pointexclude)[pointexclude],sort(df$MBvec,partial=length(df$MBvec)-pointexclude)[length(df$MBvec)-pointexclude])
    
    if(j<9){
      plot(sequence[1:lengthofplot]+shift,quantileline[1:lengthofplot,4], ylim=yrange,ylab="mass balance",main=paste("region",j),col="white",xaxt='n')
    }else{
    plot(sequence[1:lengthofplot]+shift,quantileline[1:lengthofplot,4], ylim=yrange,ylab="mass balance",main=paste("region",j),col="white")
    }
    # dev.new()
   # if (j==9){ plot(sequence[1:lengthofplot]+shift,quantileline[1:lengthofplot,4], ylim=yrange,ylab="",main=paste("region",j),col="white")}
   #   if (j==2|j==3|j==4|j==6|j==7|j==8){
   #     plot(sequence[1:lengthofplot]+shift,quantileline[1:lengthofplot,4], ylim=yrange,ylab="",main=paste("region",j),col="white",labels=FALSE)
   #   }
   #  if (j==5|j==1){
   #    plot(sequence[1:lengthofplot]+shift,quantileline[1:lengthofplot,4], ylim=yrange,ylab="",main=paste("region",j),col="white")
   #    Axis(side=1, labels=FALSE)
   #  }
   #  if (j==10|j==11){
   #    plot(sequence[1:lengthofplot]+shift,quantileline[1:lengthofplot,4], ylim=yrange,ylab="",main=paste("region",j),col="white")
   #    Axis(side=2, labels=FALSE)
   #  }
   #  

      #lines(seq(min(insamp[,i]),max(insamp[,i]),length.out=25),my_df$middle)
    #lines(seq(min(insamp[,i]),max(insamp[,i]),length.out=25),my_df$upper)  levels(hey$insamp...i.)[2]
    polygon(c(sequence[1:lengthofplot]+shift, rev(sequence[1:lengthofplot]+shift)), c(quantileline[1:lengthofplot,1], rev(quantileline[1:lengthofplot,7])), col = "grey80", border = NA)
    polygon(c(sequence[1:lengthofplot]+shift, rev(sequence[1:lengthofplot]+shift)), c(quantileline[1:lengthofplot,2], rev(quantileline[1:lengthofplot,6])), col = "grey60", border = NA)
    polygon(c(sequence[1:lengthofplot]+shift, rev(sequence[1:lengthofplot]+shift)), c(quantileline[1:lengthofplot,3], rev(quantileline[1:lengthofplot,5])), col = "grey40", border = NA)
    # polygon(c(sequence, rev(seq(min(insamp[,i])
    #                                                                   ,max(insamp[,i]),length.out=20))), c(my_df$ymin, rev(my_df$ymax)), col = "grey70", border = NA)
    # polygon(c(sequence, rev(seq(min(insamp[,i])
    #                                                                   ,max(insamp[,i]),length.out=20))), c(my_df$lower, rev(my_df$upper)), col = "grey30", border = NA)
    xlimits=par('usr')[1:2]
    valuevec=matrix(NA,19,55)
    lines(sequence[1:lengthofplot]+shift,quantileline[1:lengthofplot,4],axes=FALSE)
    for(k in 1:19){
      par(new=TRUE)
      values=o(df$MBvec[df$insamp...i.==levels(df$insamp...i.)[k]])
      # valuevec[k,1:length(values)]=values
      location=values
      location[]=c(sequence[k])
      plot(location+shift, values, ylim=yrange,xlim=xlimits,ylab="",xlab="",xaxs='i',pch=20,axes=FALSE,col=alpha("grey90",0.2))
      par(new=TRUE)
      plot(sequence+shift,mean_val,ylim=yrange,xlim=xlimits,ylab="",xlab="",xaxs='i',pch=".",axes=FALSE,col=alpha("black",0.9))
    }
    rm(df,location,values,sequence,shift,lengthofplot,xlimits)
  }
  
  for (j in 1:1){
    MBvec=MB_cumu
    shift=(max(insamp[,i])-min(insamp[,i]))/20/2
    sequence=seq(min(insamp[,i]),max(insamp[,i]),length.out=20)
    lengthofplot=length(sequence)-1
    df<-data.frame(insamp[,i],MBvec)
    df$insamp...i. <- cut(df$insamp...i., breaks = sequence)
    
    quantileline=matrix(0,20,7)
    mean_val=matrix(NA,20,1)
    for (l in 1:19){
      quantileline[l,]=f(df$MBvec[df$insamp...i.==levels(df$insamp...i.)[l]])
      mean_val[l,1]=mean(df$MBvec[df$insamp...i.==levels(df$insamp...i.)[l]],na.rm=TRUE)
    }
    
    yrange=c(sort(df$MBvec,partial=pointexclude)[pointexclude],sort(df$MBvec,partial=length(df$MBvec)-pointexclude)[length(df$MBvec)-pointexclude])
    
    # dev.new()
    plot(sequence[1:lengthofplot]+shift,quantileline[1:lengthofplot,4], ylim=yrange,ylab="mass balance",main=paste("entire GrIS"),col="white")
    #lines(seq(min(insamp[,i]),max(insamp[,i]),length.out=25),my_df$middle)
    #lines(seq(min(insamp[,i]),max(insamp[,i]),length.out=25),my_df$upper)  levels(hey$insamp...i.)[2]
    polygon(c(sequence[1:lengthofplot]+shift, rev(sequence[1:lengthofplot]+shift)), c(quantileline[1:lengthofplot,1], rev(quantileline[1:lengthofplot,7])), col = "grey80", border = NA)
    polygon(c(sequence[1:lengthofplot]+shift, rev(sequence[1:lengthofplot]+shift)), c(quantileline[1:lengthofplot,2], rev(quantileline[1:lengthofplot,6])), col = "grey60", border = NA)
    polygon(c(sequence[1:lengthofplot]+shift, rev(sequence[1:lengthofplot]+shift)), c(quantileline[1:lengthofplot,3], rev(quantileline[1:lengthofplot,5])), col = "grey40", border = NA)
    # polygon(c(sequence, rev(seq(min(insamp[,i])
    #                                                                   ,max(insamp[,i]),length.out=20))), c(my_df$ymin, rev(my_df$ymax)), col = "grey70", border = NA)
    # polygon(c(sequence, rev(seq(min(insamp[,i])
    #                                                                   ,max(insamp[,i]),length.out=20))), c(my_df$lower, rev(my_df$upper)), col = "grey30", border = NA)
    xlimits=par('usr')[1:2]
    valuevec=matrix(NA,19,55)
    lines(sequence[1:lengthofplot]+shift,quantileline[1:lengthofplot,4],axes=FALSE)
    for(k in 1:19){
      par(new=TRUE)
      values=o(df$MBvec[df$insamp...i.==levels(df$insamp...i.)[k]])
      # valuevec[k,1:length(values)]=values
      location=values
      location[]=c(sequence[k])
      plot(location+shift, values, ylim=yrange,xlim=xlimits,ylab="",xlab="",xaxs='i',pch=20,axes=FALSE,col=alpha("grey90",0.2))
      par(new=TRUE)
      plot(sequence+shift,mean_val,ylim=yrange,xlim=xlimits,ylab="surface mass balance",xlab="",xaxs='i',pch=".",axes=FALSE,col=alpha("black",0.9))
    }
    rm(df,location,values,sequence,shift,lengthofplot,xlimits)
  }
  } else if (i==7){
    i=7
   
    for (k in 1:length(MB_veci[1,])){
    MBvec=MB_veci[,k]

    df<-data.frame(insamp[,i],MBvec)
    yrange=c(sort(df$MBvec,partial=pointexclude)[pointexclude],sort(df$MBvec,partial=length(df$MBvec)-pointexclude)[length(df$MBvec)-pointexclude])
    quantileline=matrix(0,2,7)
    mean_val=matrix(NA,2,1)
    for (l in 1:2){
      quantileline[l,]=f(df$MBvec[df$insamp...i.==l-1])
      mean_val[l,1]=mean(df$MBvec[df$insamp...i.==l-1],na.rm=TRUE)
    }
    plot(1:2,quantileline[,2], ylim=yrange,ylab="mass balance",col="white",xlim=c(0.5,2.5),xaxt='n', ann=FALSE)
    
    for (j in 1:2){
      polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,1],quantileline[j,1]),rev(c(quantileline[j,7],quantileline[j,7]))), col = "grey80", border = NA,ylab="",xlab="")
      polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,2],quantileline[j,2]),rev(c(quantileline[j,6],quantileline[j,6]))), col = "grey60", border = NA,ylab="",xlab="")
      polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,3],quantileline[j,3]),rev(c(quantileline[j,5],quantileline[j,5]))), col = "grey40", border = NA,ylab="",xlab="")
      lines(c(j-0.4,j+0.4),c(quantileline[j,4],quantileline[j,4]),ylab="",xlab="",axes=FALSE)
      values=o(df$MBvec[df$insamp...i.==j-1])
      location=values
      location[]=j
      xlimits=par('usr')[1:2]
      par(new=TRUE)
      plot(location, values, ylim=yrange,xlim=xlimits,ylab="",xlab="",xaxs='i',pch=20,axes=FALSE,col=alpha("grey90",0.2),main=k)
      par(new=TRUE)
      plot(j,mean_val[j,1],ylim=yrange,xlim=xlimits,ylab="",xlab=TeX('$\\chi_{QL}$'),xaxs='i',pch=".",axes=FALSE,col=alpha("black",0.9))
    }
    quantity=c("QL off","QL on")
    axis(1,at=1:2,labels=quantity,cex.axis=0.7)
    }
    for (k in 1:1){
      MBvec=MB_cumu
      df<-data.frame(insamp[,i],MBvec)
      yrange=c(sort(df$MBvec,partial=pointexclude)[pointexclude],sort(df$MBvec,partial=length(df$MBvec)-pointexclude)[length(df$MBvec)-pointexclude])
      quantileline=matrix(0,2,7)
      mean_val=matrix(NA,2,1)
      for (l in 1:2){
        quantileline[l,]=f(df$MBvec[df$insamp...i.==l-1])
        mean_val[l,1]=mean(df$MBvec[df$insamp...i.==l-1],na.rm=TRUE)
      }
      plot(1:2,quantileline[,2], ylim=yrange,ylab="mass balance",col="white",xlim=c(0.5,2.5),xaxt='n', ann=FALSE)
      
      for (j in 1:2){
        polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,1],quantileline[j,1]),rev(c(quantileline[j,7],quantileline[j,7]))), col = "grey80", border = NA,ylab="",xlab="")
        polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,2],quantileline[j,2]),rev(c(quantileline[j,6],quantileline[j,6]))), col = "grey60", border = NA,ylab="",xlab="")
        polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,3],quantileline[j,3]),rev(c(quantileline[j,5],quantileline[j,5]))), col = "grey40", border = NA,ylab="",xlab="")
        lines(c(j-0.4,j+0.4),c(quantileline[j,4],quantileline[j,4]),ylab="",xlab="",axes=FALSE)
        values=o(df$MBvec[df$insamp...i.==j-1])
        location=values
        location[]=j
        xlimits=par('usr')[1:2]
        par(new=TRUE)
        plot(location, values, ylim=yrange,xlim=xlimits,ylab="",xlab="",xaxs='i',pch=20,axes=FALSE,col=alpha("grey90",0.2),main="entire GrIS")
        par(new=TRUE)
        plot(j,mean_val[j,1],ylim=yrange,xlim=xlimits,ylab="",xlab="",xaxs='i',pch=".",axes=FALSE,col=alpha("black",0.9))
      }
      quantity=c("QL off","QL on")
      axis(1,at=1:2,labels=quantity,cex.axis=0.7)
    }
  } else if (i==8) {
    i=8
    for (k in 1:length(MB_veci[1,])){
      MBvec=MB_veci[,k]
    df<-data.frame(insamp[,i],MBvec)
    df$insamp...i.[df$insamp...i.==5]=2
    yrange=c(sort(df$MBvec,partial=pointexclude)[pointexclude],sort(df$MBvec,partial=length(df$MBvec)-pointexclude)[length(df$MBvec)-pointexclude])
    quantileline=matrix(0,4,7)
    mean_val=matrix(NA,4,1)
    for (l in 1:4){
      quantileline[l,]=f(df$MBvec[df$insamp...i.==l])
      mean_val[l,1]=mean(df$MBvec[df$insamp...i.==l],na.rm=TRUE)
    }
    plot(1:4,quantileline[,4], ylim=yrange,ylab="mass balance",main=parameter_vec[i],col="white",xlim=c(0.5,4.5),xaxt='n', ann=FALSE,yaxt='n')
    
    for (j in 1:4){
      polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,1],quantileline[j,1]),rev(c(quantileline[j,7],quantileline[j,7]))), col = "grey80", border = NA,ylab="",xlab="")
      polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,2],quantileline[j,2]),rev(c(quantileline[j,6],quantileline[j,6]))), col = "grey60", border = NA,ylab="",xlab="")
      polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,3],quantileline[j,3]),rev(c(quantileline[j,5],quantileline[j,5]))), col = "grey40", border = NA,ylab="",xlab="")
      lines(c(j-0.4,j+0.4),c(quantileline[j,4],quantileline[j,4]),ylab="",xlab="",axes=FALSE)
      values=o(df$MBvec[df$insamp...i.==j])
      location=values
      location[]=j
      xlimits=par('usr')[1:2]
      par(new=TRUE)
      plot(location, values, ylim=yrange,xlim=xlimits,ylab="",xlab="",xaxs='i',pch=20,axes=FALSE,col=alpha("grey90",0.2),main=parameter_vec[i])
      par(new=TRUE)
      plot(j,mean_val[j,1],ylim=yrange,xlim=xlimits,ylab="",xlab="",xaxs='i',pch=".",axes=FALSE,col=alpha("black",0.9))
    }
    quantity=c("constant","Bouga","Oerlemans","Aoki")
    axis(1,at=1:4,labels=quantity,cex.axis=0.7)
    }
    for (k in 1:1){
      MBvec=MB_cumu
      df<-data.frame(insamp[,i],MBvec)
      df$insamp...i.[df$insamp...i.==5]=2
      yrange=c(sort(df$MBvec,partial=pointexclude)[pointexclude],sort(df$MBvec,partial=length(df$MBvec)-pointexclude)[length(df$MBvec)-pointexclude])
      quantileline=matrix(0,4,7)
      mean_val=matrix(NA,4,1)
      for (l in 1:4){
        quantileline[l,]=f(df$MBvec[df$insamp...i.==l])
        mean_val[l,1]=mean(df$MBvec[df$insamp...i.==l],na.rm=TRUE)
      }
      plot(1:4,quantileline[,4], ylim=yrange,ylab="mass balance",main=i,col="white",xlim=c(0.5,4.5),xaxt='n', ann=FALSE,yaxt='n')
      
      for (j in 1:4){
        polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,1],quantileline[j,1]),rev(c(quantileline[j,7],quantileline[j,7]))), col = "grey80", border = NA,ylab="",xlab="")
        polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,2],quantileline[j,2]),rev(c(quantileline[j,6],quantileline[j,6]))), col = "grey60", border = NA,ylab="",xlab="")
        polygon(c(c(j-0.4,j+0.4),rev(c(j-0.4,j+0.4))),c(c(quantileline[j,3],quantileline[j,3]),rev(c(quantileline[j,5],quantileline[j,5]))), col = "grey40", border = NA,ylab="",xlab="")
        lines(c(j-0.4,j+0.4),c(quantileline[j,4],quantileline[j,4]),ylab="",xlab="",axes=FALSE)
        values=o(df$MBvec[df$insamp...i.==j])
        location=values
        location[]=j
        xlimits=par('usr')[1:2]
        par(new=TRUE)
        plot(location, values, ylim=yrange,xlim=xlimits,ylab="",xlab="",xaxs='i',pch=20,axes=FALSE,col=alpha("grey90",0.2),main="entire GrIS")
        par(new=TRUE)
        plot(j,mean_val[j,1],ylim=yrange,xlim=xlimits,ylab="",xlab="",xaxs='i',pch=".",axes=FALSE,col=alpha("black",0.9))
      }
      quantity=c("constant","Bouga","Oerlemans","Aoki")
      axis(1,at=1:4,labels=quantity,cex.axis=0.7)
      title(main=paste("h"),adj  =0.2, line=-2)
      legend("topleft", "I)", bty="n")
      legend("bottomright", "I2)", bty="n")
    }
  }
  # cols = rev(colorRampPalette(c('black','grey'))(16))
  # cols = rev(colorRampPalette(c('darkred','red','blue','lightblue','lightgreen','green','yellow','grey','grey50','black'))(28))
  # image(as.matrix(t(map)),col=cols,axes=FALSE) 
 
  #mtext(expression('surface mass balance  kgm'^{-2}), side=2, line=1, outer=TRUE)
  mtext(~paste("surface mass balance ", "(kgm"^-2,')'), side=2, line=1, outer=TRUE)
  mtext(parameter_vec[i], side=1, line=2.5, outer=TRUE)
  mtext('west', side=3, line=1,adj=0.11, outer=TRUE)
  mtext('north', side=3, line=1,adj=0.38, outer=TRUE)
  mtext('east', side=3, line=1,adj=0.64, outer=TRUE)
  mtext('south/east', side=3, line=1,adj=0.94, outer=TRUE)
  # text('Results6', side=4, line=-15, outer=TRUE,srt=90)
   dev.off()
  # dev.new()
  # image(as.matrix(t(map)),col=cols,axes=FALSE) 
}
