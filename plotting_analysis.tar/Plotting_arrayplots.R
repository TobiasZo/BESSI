#plotting script:
#regions straight
rm(list=ls(all=TRUE))
period="ERAi"
ensemblesize=11000
pointexclude=10 #in the plot how many outliers should not be scaled 
variable="mass_balance"
dir.create(paste("/home/tobias/PhD/Programming/NEW/modeloutput/plots/arrayplot/",variable,sep=""),showWarnings = FALSE)

source('/home/tobias/PhD/Programming/NEW/modeloutput/Analysis_scripts/read_ensemble_variable.R')
MB<-read_ensemble_variable(variable,ensemblesize,period)
MB=MB/100
gc()
source("/home/tobias/PhD/Programming/NEW/modeloutput/Analysis_scripts/R_cumulative_MB.R")
gc()

gc()
source('/home/tobias/PhD/Programming/NEW/modeloutput/Analysis_scripts/Create_ensemble_matrix_for_analysis.R')

source("/home/tobias/PhD/Programming/NEW/modeloutput/Analysis_scripts/map_join_function.R")
regions_grad_ele=map_join(elevation_mask,regions_grad)

Regions_grad_ele=region_calculation(MB,regions_grad_ele,ensemblesize) #calculating variable vector based on region mask
reg_test=regions_grad_ele
gc()
xing=regions_grad_ele
xing[1:75,]=TRUE
xing[76:281,]=FALSE
# reg_test[reg_test==4&xing]=40
# reg_test[reg_test==4&!xing]=0
reg_test[reg_test>28]=42
reg_test[reg_test==10|reg_test==24]=31 #30

  reg_test[reg_test==11|reg_test==25]= 35#31
  reg_test[reg_test==12|reg_test==13|reg_test==26|reg_test==27]=39#32
  reg_test[reg_test==1|reg_test==5]=30 #33 
  reg_test[reg_test==2|reg_test==6]=34
  reg_test[reg_test==3|reg_test==7|reg_test==8|(reg_test==4&!xing)]=38 #35
  reg_test[reg_test==14]= 33 #36
  reg_test[reg_test==15|reg_test==16|reg_test==17|reg_test==18|(reg_test==4&xing)]=37#37
    reg_test[reg_test==19|reg_test==20]=32#38
  reg_test[reg_test==21|reg_test==22|reg_test==23]=36#39
  reg_test[reg_test==9]=40
  reg_test[reg_test==28]=40
  reg_test[reg_test<30]=29
  reg_test=reg_test-29
  gc()
  Reg_test=region_calculation(MB,reg_test,ensemblesize)
  
subsamp=samp
special="all"
outvec=array(TRUE,length(subsamp[,1]))

#remove latent heat off runs
#  for (i in 1:length(subsamp[,1])){
#   if (subsamp[i,7]==0){outvec[i]=FALSE}
#  }
# special="QLon"

#indiviudal albedos:
# outvec=array(FALSE,length(subsamp[,1]))
# for (i in 1:length(subsamp[,1])){
#   if (subsamp[i,8]==1){outvec[i]=TRUE}
# }
# special="constant"

# for (i in 1:length(subsamp[,1])){
#   if (subsamp[i,8]==3){outvec[i]=TRUE}
# }
# special="Oerlemans"

# for (i in 1:length(subsamp[,1])){
#   if (subsamp[i,8]==4){outvec[i]=TRUE}
# }
# special="Aoki"

# for (i in 1:length(subsamp[,1])){
#   if (subsamp[i,8]==5){outvec[i]=TRUE}
# }
# special="Boug"
#MB[MB==290]=270
 outmatrix=subsamp[outvec,]

 source('/home/tobias/PhD/Programming/NEW/modeloutput/Analysis_scripts/plotting_functions.R')
# # by region -------------------------------------------
# MB_vec=MB_regions_grad[outvec,]
# area=Area_regions_grad
# size=length(MB_vec[,1])
# name=deparse(substitute(MB_regions_grad))
# for (i in 1:length(MB_vec[1,])){
# pdfname=paste("plots/arrayplot/",variable,"/",name,i,"_",special,"_",size,period,".pdf",sep='')
# # pdfname="test.pdf"
# plot_ensemble(pdfname,MB_vec[,i]/area[i],pointexclude,outmatrix)
# }
# rm (MB_vec)
# 
# MB_vec=MB_regional[outvec,]
# area=Area_regional
# size=length(MB_vec[,1])
# name=deparse(substitute(MB_regional))
# for (i in 1:length(MB_vec[1,])){
#   pdfname=paste("plots/arrayplot/",variable,"/",name,i,"_",special,"_",size,period,".pdf",sep='')
#   plot_ensemble(pdfname,MB_vec[,i]/area[i],pointexclude,outmatrix)
# }
# rm (MB_vec)
# 
# MB_vec=MB_elevation[outvec,]
# area=Area_elevation
# size=length(MB_vec[,1])
# name=deparse(substitute(MB_elevation))
# for (i in 1:length(MB_vec[1,])){
#   pdfname=paste("plots/arrayplot/",variable,"/",name,i,"_",special,"_",size,period,".pdf",sep='')
#   plot_ensemble(pdfname,MB_vec[,i]/area[i],pointexclude,outmatrix)
# }
# rm (MB_vec)
# 
# MB_vec=MB_elevation_cum[outvec,]
# area=Area_elevation_cum
# size=length(MB_vec[,1])
# name=deparse(substitute(MB_elevation_cum))
# for (i in 1:length(MB_vec[1,])){
#   pdfname=paste("plots/arrayplot/",variable,"/",name,i,"_",special,"_",size,period,".pdf",sep='')
#   plot_ensemble(pdfname,MB_vec[,i]/area[i],pointexclude,outmatrix)
# }
# rm (MB_vec)
# 
# MB_vec=Regions_grad_ele$var_vec[outvec,]
# area=Regions_grad_ele$area
# size=length(MB_vec[,1])
# name=deparse(substitute(Regions_grad_ele))
# for (i in 1:length(MB_vec[1,])){
#   pdfname=paste("plots/arrayplot/",variable,"/",name,i,"_",special,"_",size,period,".pdf",sep='')
#   plot_ensemble(pdfname,MB_vec[,i]/area[i],pointexclude,outmatrix)
# }
# rm (MB_vec)
# 
# MB_vec=MB_cumulative[outvec]
# area=Area_cumulative
# size=length(MB_vec)
# name=deparse(substitute(MB_cumulative))
#   pdfname=paste("plots/arrayplot/",variable,"/",name,"_",special,"_",size,period,".pdf",sep='')
#   plot_ensemble(pdfname,MB_vec/area,pointexclude,outmatrix)
# rm (MB_vec)
# 
MB_vec=Reg_test$var_vec[outvec,]
area=Reg_test$area
size=length(MB_vec[,1])
name=deparse(substitute(Reg_test))
for (i in 1:length(MB_vec[1,])){
  pdfname=paste("plots/arrayplot/",variable,"/",name,i,"_",special,"_",size,period,".pdf",sep='')
  plot_ensemble(pdfname,MB_vec[,i]/area[i],pointexclude,outmatrix)
}
rm (MB_vec)

# #temperature pointwise
# # for (i in 1:length(vec[,1])){
# # MB_vec=MB[vec[i,1],vec[i,2],outvec]
# # size=length(MB_vec)
# # name=deparse(substitute(Snow_temp))
# # pdfname=paste("plots/arrayplot/",variable,"/",name,"_",special,"_",size,period,vec[i,1],vec[i,2],".pdf",sep='')
# # plot_ensemble(pdfname,MB_vec[MB_vec!=290],pointexclude,outmatrix[MB_vec!=290,])
# # }
# # rm (MB_vec)
# # MB_vec=matrix(NA,length(MB[1,1,outvec]),length(vec[,1]))
# # matrix=assignment_mask_i
# # for (i in 1:length(vec[,1])){
# # MB_vec[,i]=MB[vec[i,1],vec[i,2],outvec]
# # matrix[vec[i,1],vec[i,2]]=-1
# # }
# # for (i in 1:9){
# #   plot_parameter_sensitivity(paste("plots/arrayplot/",variable,"/","elevation_cum",size,period,sep=""),MB_vec[,],MB_vec[,1],i,pointexclude,outmatrix,matrix)
# # }
# 
# 
# # by parameter ------------------------
# specific=MB_elevation_cum[outvec,]
# specific[]=0
# for (i in 1:length(specific[1,])){
#   specific[,i]=MB_elevation_cum[outvec,i]/Area_elevation_cum[i]
#   i
# }
# for (i in 1:9){
# plot_parameter_sensitivity(paste("plots/arrayplot/",variable,"/","elevation_cum",size,period,sep=""),specific,MB_cumulative[outvec]/Area_cumulative,i,pointexclude,outmatrix,elevation_mask)
# }
# 
# specific=MB_elevation[outvec,]
# specific[]=NaN
# for (i in 1:length(specific[1,])){
#   specific[,i]=MB_elevation[outvec,i]/Area_elevation[i]
# }
# for (i in 1:9){
#   plot_parameter_sensitivity(paste("plots/arrayplot/",variable,"/","elevation",size,period,sep=""),specific,MB_cumulative[outvec]/Area_cumulative,i,pointexclude,outmatrix,elevation_mask)
# }
# 
# specific=MB_regions_grad[outvec,]
# specific[]=NaN
# for (i in 1:length(specific[1,])){
#   specific[,i]=MB_regions_grad[outvec,i]/Area_regions_grad[i]
# }
# for (i in 1:9){
#   plot_parameter_sensitivity(paste("plots/arrayplot/",variable,"/","regions_grad",size,period,sep=""),specific,MB_cumulative[outvec]/Area_cumulative,i,pointexclude,outmatrix,elevation_mask)
# }
specific=Reg_test[["var_vec"]][outvec,]
specific[]=NaN
for (i in 1:length(specific[1,])){
  specific[,i]=Reg_test[["var_vec"]][outvec,i]/Reg_test[["area"]][i]

}
for (i in 1:9){
  plot_parameter_sensitivity(paste("plots/arrayplot/",variable,"/","Reg_testT",size,period,sep=""),specific,MB_cumulative[outvec]/Area_cumulative,i,pointexclude,outmatrix,Reg_test$mask)
}
# specific=MB_regional[outvec,]
# specific[]=NaN
# for (i in 1:length(specific[1,])){
#   specific[,i]=MB_regional[outvec,i]/Area_regional[i]
# }
# for (i in 1:9){
#   plot_parameter_sensitivity(paste("plots/arrayplot/",variable,"/","regional","_",size,period,sep=""),specific,MB_cumulative[outvec]/Area_cumulative,i,pointexclude,outmatrix,region_mask)
# }
# specific=Regions_grad_ele[["var_vec"]][outvec,]
# specific[]=NaN
# for (i in 1:length(specific[1,])){
#   specific[,i]=Regions_grad_ele[["var_vec"]][outvec,i]/Regions_grad_ele[["area"]][i]
#   
# }
# for (i in 1:9){
#   plot_parameter_sensitivity(paste("plots/arrayplot/",variable,"/","regional_elevation",size,period,sep=""),specific,MB_cumulative[outvec]/Area_cumulative,i,pointexclude,outmatrix,Regions_grad_ele$mask)
# }
# for (i in 1:9){
#   plot_parameter_sensitivity(paste("plots/arrayplot/",variable,"/","Reg_test",size,period,sep=""),specific,MB_cumulative[outvec]/Area_cumulative,i,pointexclude,outmatrix,Reg_test$mask)
# }


# latent heat on ----------
subsamp=samp
special="all"
outvec=array(TRUE,length(subsamp[,1]))

#remove latent heat off runs
 for (i in 1:length(subsamp[,1])){
  if (subsamp[i,7]==0){outvec[i]=FALSE}
 }
special="QLon"

#indiviudal albedos:
# outvec=array(FALSE,length(subsamp[,1]))
# for (i in 1:length(subsamp[,1])){
#   if (subsamp[i,8]==1){outvec[i]=TRUE}
# }
# special="constant"

# for (i in 1:length(subsamp[,1])){
#   if (subsamp[i,8]==3){outvec[i]=TRUE}
# }
# special="Oerlemans"

# for (i in 1:length(subsamp[,1])){
#   if (subsamp[i,8]==4){outvec[i]=TRUE}
# }
# special="Aoki"

# for (i in 1:length(subsamp[,1])){
#   if (subsamp[i,8]==5){outvec[i]=TRUE}
# }
# special="Boug"
#MB[MB==290]=270
outmatrix=subsamp[outvec,]

source('/home/tobias/PhD/Programming/NEW/modeloutput/Analysis_scripts/plotting_functions.R')
# # by region -------------------------------------------
# MB_vec=MB_regions_grad[outvec,]
# area=Area_regions_grad
# size=length(MB_vec[,1])
# name=deparse(substitute(MB_regions_grad))
# for (i in 1:length(MB_vec[1,])){
#   pdfname=paste("plots/arrayplot/",variable,"/",name,i,"_",special,"_",size,period,".pdf",sep='')
#   # pdfname="test.pdf"
#   plot_ensemble(pdfname,MB_vec[,i]/area[i],pointexclude,outmatrix)
# }
# rm (MB_vec)
# 
# MB_vec=MB_regional[outvec,]
# area=Area_regional
# size=length(MB_vec[,1])
# name=deparse(substitute(MB_regional))
# for (i in 1:length(MB_vec[1,])){
#   pdfname=paste("plots/arrayplot/",variable,"/",name,i,"_",special,"_",size,period,".pdf",sep='')
#   plot_ensemble(pdfname,MB_vec[,i]/area[i],pointexclude,outmatrix)
# }
# rm (MB_vec)
# 
# MB_vec=MB_elevation[outvec,]
# area=Area_elevation
# size=length(MB_vec[,1])
# name=deparse(substitute(MB_elevation))
# for (i in 1:length(MB_vec[1,])){
#   pdfname=paste("plots/arrayplot/",variable,"/",name,i,"_",special,"_",size,period,".pdf",sep='')
#   plot_ensemble(pdfname,MB_vec[,i]/area[i],pointexclude,outmatrix)
# }
# rm (MB_vec)
# 
# MB_vec=MB_elevation_cum[outvec,]
# area=Area_elevation_cum
# size=length(MB_vec[,1])
# name=deparse(substitute(MB_elevation_cum))
# for (i in 1:length(MB_vec[1,])){
#   pdfname=paste("plots/arrayplot/",variable,"/",name,i,"_",special,"_",size,period,".pdf",sep='')
#   plot_ensemble(pdfname,MB_vec[,i]/area[i],pointexclude,outmatrix)
# }
# rm (MB_vec)
# 
# MB_vec=Regions_grad_ele$var_vec[outvec,]
# area=Regions_grad_ele$area
# size=length(MB_vec[,1])
# name=deparse(substitute(Regions_grad_ele))
# for (i in 1:length(MB_vec[1,])){
#   pdfname=paste("plots/arrayplot/",variable,"/",name,i,"_",special,"_",size,period,".pdf",sep='')
#   plot_ensemble(pdfname,MB_vec[,i]/area[i],pointexclude,outmatrix)
# }
# rm (MB_vec)
# 

MB_vec=Reg_test$var_vec[outvec,]
area=Reg_test$area
size=length(MB_vec[,1])
name=deparse(substitute(Reg_test))
for (i in 1:length(MB_vec[1,])){
  pdfname=paste("plots/arrayplot/",variable,"/",name,i,"_",special,"_",size,period,".pdf",sep='')
  plot_ensemble(pdfname,MB_vec[,i]/area[i],pointexclude,outmatrix)
}
rm (MB_vec)
# 
# MB_vec=MB_cumulative[outvec]
# area=Area_cumulative
# size=length(MB_vec)
# name=deparse(substitute(MB_cumulative))
# pdfname=paste("plots/arrayplot/",variable,"/",name,"_",special,"_",size,period,".pdf",sep='')
# plot_ensemble(pdfname,MB_vec/area,pointexclude,outmatrix)
# rm (MB_vec)
# 
# #temperature pointwise
# # for (i in 1:length(vec[,1])){
# # MB_vec=MB[vec[i,1],vec[i,2],outvec]
# # size=length(MB_vec)
# # name=deparse(substitute(Snow_temp))
# # pdfname=paste("plots/arrayplot/",variable,"/",name,"_",special,"_",size,period,vec[i,1],vec[i,2],".pdf",sep='')
# # plot_ensemble(pdfname,MB_vec[MB_vec!=290],pointexclude,outmatrix[MB_vec!=290,])
# # }
# # rm (MB_vec)
# # MB_vec=matrix(NA,length(MB[1,1,outvec]),length(vec[,1]))
# # matrix=assignment_mask_i
# # for (i in 1:length(vec[,1])){
# # MB_vec[,i]=MB[vec[i,1],vec[i,2],outvec]
# # matrix[vec[i,1],vec[i,2]]=-1
# # }
# # for (i in 1:9){
# #   plot_parameter_sensitivity(paste("plots/arrayplot/",variable,"/","elevation_cum",size,period,sep=""),MB_vec[,],MB_vec[,1],i,pointexclude,outmatrix,matrix)
# # }
# 
# 
# # by parameter ------------------------
# specific=MB_elevation_cum[outvec,]
# specific[]=0
# for (i in 1:length(specific[1,])){
#   specific[,i]=MB_elevation_cum[outvec,i]/Area_elevation_cum[i]
#   i
# }
# for (i in 1:9){
#   plot_parameter_sensitivity(paste("plots/arrayplot/",variable,"/","elevation_cum",size,period,sep=""),specific,MB_cumulative[outvec]/Area_cumulative,i,pointexclude,outmatrix,elevation_mask)
# }
# 
# specific=MB_elevation[outvec,]
# specific[]=NaN
# for (i in 1:length(specific[1,])){
#   specific[,i]=MB_elevation[outvec,i]/Area_elevation[i]
# }
# for (i in 1:9){
#   plot_parameter_sensitivity(paste("plots/arrayplot/",variable,"/","elevation",size,period,sep=""),specific,MB_cumulative[outvec]/Area_cumulative,i,pointexclude,outmatrix,elevation_mask)
# }
# 
# specific=MB_regions_grad[outvec,]
# specific[]=NaN
# for (i in 1:length(specific[1,])){
#   specific[,i]=MB_regions_grad[outvec,i]/Area_regions_grad[i]
# }
# for (i in 1:9){
#   plot_parameter_sensitivity(paste("plots/arrayplot/",variable,"/","regions_grad",size,period,sep=""),specific,MB_cumulative[outvec]/Area_cumulative,i,pointexclude,outmatrix,regions_grad)
# }
# 
# specific=MB_regional[outvec,]
# specific[]=NaN
# for (i in 1:length(specific[1,])){
#   specific[,i]=MB_regional[outvec,i]/Area_regional[i]
# }
# for (i in 1:9){
#   plot_parameter_sensitivity(paste("plots/arrayplot/",variable,"/","regional","_",size,period,sep=""),specific,MB_cumulative[outvec]/Area_cumulative,i,pointexclude,outmatrix,region_mask)
# }
# specific=Regions_grad_ele[["var_vec"]][outvec,]
# specific=Regions_grad_ele[["var_vec"]][outvec,]
# specific[]=NaN
# for (i in 1:length(specific[1,])){
#   specific[,i]=Regions_grad_ele[["var_vec"]][outvec,i]/Regions_grad_ele[["area"]][i]
#   
# }
# for (i in 1:9){
#   plot_parameter_sensitivity(paste("plots/arrayplot/",variable,"/","Regions_grad_ele",size,period,sep=""),specific,MB_cumulative[outvec]/Area_cumulative,i,pointexclude,outmatrix,Regions_grad_ele$mask)
# }
# 
specific=Reg_test[["var_vec"]][outvec,]
specific[]=NaN
for (i in 1:length(specific[1,])){
  specific[,i]=Reg_test[["var_vec"]][outvec,i]/Reg_test[["area"]][i]

}
for (i in 1:9){
  plot_parameter_sensitivity(paste("plots/arrayplot/",variable,"/","Reg_test",size,period,sep=""),specific,MB_cumulative[outvec]/Area_cumulative,i,pointexclude,outmatrix,Reg_test$mask)
}
